import base64
import zlib
import sys

def obfuscate_code(code):
    # Comprime o código usando zlib
    compressed = zlib.compress(code.encode('utf-8'))
    # Codifica em base64
    encoded = base64.b64encode(compressed)
    # Inverte a string
    reversed_encoded = encoded[::-1]
    # Cria o código ofuscado
    obfuscated = f"""_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'{reversed_encoded.decode()}'))"""
    return obfuscated

# Ler o código original
with open('faustinotv.py', 'r', encoding='utf-8') as f:
    original_code = f.read()

# Gerar código ofuscado
obfuscated_code = obfuscate_code(original_code)

# Salvar código ofuscado
with open('addon_obfuscated.py', 'w', encoding='utf-8') as f:
    f.write(obfuscated_code)

print("Código ofuscado salvo em addon_obfuscated.py")